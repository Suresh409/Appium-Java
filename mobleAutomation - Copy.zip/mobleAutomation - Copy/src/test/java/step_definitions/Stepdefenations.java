package step_definitions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Platform;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class Stepdefenations {
	private  RemoteWebDriver driver;
    Properties prop = new Properties();
    
    @Before
    public void startDriver() throws IOException, InterruptedException {
    	
    	InputStream input = null;
    	input = new FileInputStream("config.properties");
    	prop.load(input);
    	System.out.println(prop.getProperty("deviceType"));
    	
if(prop.getProperty("deviceType").equalsIgnoreCase("AndroidWeb")){
	InputStream input1 = null;
	input1 = new FileInputStream("C:\\AppiumJava\\mobleAutomation\\OR\\androidWeb.properties");
	prop.load(input1);
	DesiredCapabilities capabilities = new DesiredCapabilities("Chrome","",Platform.ANY);
	capabilities.setCapability("browsername", "chrome");
	capabilities.setCapability("deviceName", "0123456789ABCDEF");
	capabilities.setCapability("platformName", "Android");
	driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
	Thread.sleep(8000);
	driver.get("http://www.seleniumframework.com");
}else if(prop.getProperty("deviceType").equalsIgnoreCase("Android")){
	System.out.println("Inside Android Natve App launch code");
	InputStream input1 = null;
	input1 = new FileInputStream("C:\\AppiumJava\\mobleAutomation\\OR\\androidWeb.properties");
	prop.load(input1);
	DesiredCapabilities capabilities = new DesiredCapabilities();
	capabilities.setCapability("deviceName", "0123456789ABCDEF");
	capabilities.setCapability("platformName", "Android");
	capabilities.setCapability("app", "C:\\AppiumJava\\mobleAutomation\\Flipkart_4.4.2.apk");
	capabilities.setCapability("appPackage", "com.flipkart.android");
	capabilities.setCapability("appWaitActivity", "com.flipkart.android.SplashActivity");
	driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
	Thread.sleep(8000);
	
}else if(prop.getProperty("deviceType").equalsIgnoreCase("Chrome")){
	InputStream input2 = null;
	input2 = new FileInputStream("C:\\AppiumJava\\mobleAutomation\\OR\\webOR.properties");
	prop.load(input2);
	System. setProperty("webdriver.chrome.driver", "C:\\AppiumJava\\mobleAutomation\\DriverScripts\\Selenium\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("http://www.seleniumframework.com");
}else if(prop.getProperty("deviceType").equalsIgnoreCase("iOSWeb")){
	InputStream input1 = null;
	input1 = new FileInputStream("C:\\AppiumJava\\mobleAutomation\\OR\\androidWeb.properties");
	prop.load(input1);
	DesiredCapabilities capabilities = new DesiredCapabilities("safari","",Platform.ANY);
	capabilities.setCapability("browsername", "safari");
	capabilities.setCapability("deviceName", "0123456789ABCDEF");
	capabilities.setCapability("platformName", "iOS");
	driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
	Thread.sleep(8000);
	driver.get("http://www.seleniumframework.com");
}else if(prop.getProperty("deviceType").equalsIgnoreCase("iOS")){
	System.out.println("Inside iOS Natve App launch code");
	InputStream input1 = null;
	input1 = new FileInputStream("C:\\AppiumJava\\mobleAutomation\\OR\\androidWeb.properties");
	prop.load(input1);
	DesiredCapabilities capabilities = new DesiredCapabilities();
	capabilities.setCapability(CapabilityType.BROWSER_NAME, "iOS");
	capabilities.setCapability(CapabilityType.VERSION, "6.1");
	capabilities.setCapability(CapabilityType.PLATFORM, "Mac");
	capabilities.setCapability("app","/Users/username/Downloads/InternationalMountains   /build/Release-iphonesimulator/InternationalMountains.app");
	driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
	Thread.sleep(8000);
	
}

    }
    public RemoteWebDriver getDriver() {
        return driver;
     }
    
      
    @Given("^I open seleniumframework website$")
    public void i_open_seleniumframework_website() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
        //driver.manage().window().maximize();
        
    }

    @And("^I navigate to ABOUT link$")
    public void i_navigate_to_ABOUT_link() throws Throwable {
        WebDriverWait wait = new WebDriverWait(driver,10);
        wait.ignoring(WebDriverException.class);
        wait.ignoring(StaleElementReferenceException.class);
        wait.until(ExpectedConditions.elementToBeClickable(By.linkText(prop.getProperty("linkText"))));
        driver.findElement(By.linkText(prop.getProperty("linkText"))).click();
    }

   
    
}